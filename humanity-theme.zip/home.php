<?php

/**
 * Post type archive template
 *
 * @package Amnesty\Templates
 */

require_once 'archive.php';
