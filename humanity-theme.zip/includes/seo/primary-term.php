<?php

declare( strict_types = 1 );

add_filter( 'wpseo_primary_term_taxonomies', '__return_empty_array' );
