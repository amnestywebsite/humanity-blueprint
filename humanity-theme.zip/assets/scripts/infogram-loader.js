(()=>{(function(){const e=document.createElement("script");e.async=1,e.id="infogram-async",document.head.appendChild(e),e.src="https://e.infogram.com/js/dist/embed-loader-min.js"})();})();

//# sourceMappingURL=infogram-loader.js.map